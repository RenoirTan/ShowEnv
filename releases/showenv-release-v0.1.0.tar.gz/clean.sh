#!/bin/sh

rm -rf aclocal.m4 autom4te.cache config.log config.status configure install-sh Makefile Makefile.in missing
